<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Servers;

use Pterodactyl\Models\Server;
use Pterodactyl\Models\Permission;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Pterodactyl\Models\Filters\MultiFieldServerFilter;
use Pterodactyl\Repositories\Eloquent\ServerRepository;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Pterodactyl\Transformers\Api\Client\ServerTransformer;
use Pterodactyl\Http\Requests\Api\Client\GetServersRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Exceptions\DisplayException;

class VersionsController extends ClientApiController
{
    /**
     * @var \Pterodactyl\Repositories\Eloquent\ServerRepository
     */
    private $repository;

    /**
     * ClientController constructor.
     */
    public function __construct(ServerRepository $repository)
    {
        parent::__construct();

        $this->repository = $repository;
    }
    public function vanilla(Request $request)
    {    	    
        $pteroaddon = Http::accept('application/json')->get('https://gameversion.bagou450.com/minecraft/listofversion/verification.json')->object();
        if($pteroaddon->verified === false) {
            throw new DisplayException('Pirated (This addon was pirated or not updated me on discord Bagou450#0666 or Yotapaki#8953 for talk about that)');
        }
   	    $versions = Http::accept('application/json')->get('https://serverjars.com/api/fetchAll/vanilla')->object();
	    return json_encode($versions);
    }
    public function spigot(Request $request)
    {    	   
        $pteroaddon = Http::accept('application/json')->get('https://gameversion.bagou450.com/minecraft/listofversion/verification.json')->object();
        if($pteroaddon->verified === false) {
            throw new DisplayException('Pirated (This addon was pirated or not updated contact me on discord Bagou450#0666 or Yotapaki#8953 for talk about that)');
        } 
   	    $versions = Http::accept('application/json')->get('https://serverjars.com/api/fetchAll/spigot')->object();
	    return json_encode($versions);
    }
    public function paper(Request $request)
    {    	 
        $pteroaddon = Http::accept('application/json')->get('https://gameversion.bagou450.com/minecraft/listofversion/verification.json')->object();
        if($pteroaddon->verified === false) {
            throw new DisplayException('Pirated (This addon was pirated or not updated contact me on discord Bagou450#0666 or Yotapaki#8953 for talk about that)');
        }   
   	    $versions = Http::accept('application/json')->get('https://serverjars.com/api/fetchAll/paper')->object();
	    return json_encode($versions);
    }
    public function forge(Request $request)
    {    
        $pteroaddon = Http::accept('application/json')->get('https://gameversion.bagou450.com/minecraft/listofversion/verification.json')->object();
        if($pteroaddon->verified === false) {
            throw new DisplayException('Pirated (This addon was pirated or not updated contact me on discord Bagou450#0666 or Yotapaki#8953 for talk about that)');
        }	    
   	    $versions = Http::accept('application/json')->get('https://gameversion.bagou450.com/minecraft/listofversion/Forge.json')->object();
	    return $versions;
    }
    public function fabric(Request $request)
    {    	
        $pteroaddon = Http::accept('application/json')->get('https://gameversion.bagou450.com/minecraft/listofversion/verification.json')->object();
        if($pteroaddon->verified === false) {
            throw new DisplayException('Pirated (This addon was pirated or not updated contact me on discord Bagou450#0666 or Yotapaki#8953 for talk about that)');
        }    
   	    $versions = Http::accept('application/json')->get('https://gameversion.bagou450.com/minecraft/listofversion/Fabric.json')->object();
	    return $versions;
    }
    public function mohist(Request $request)
    {    	 
        $pteroaddon = Http::accept('application/json')->get('https://gameversion.bagou450.com/minecraft/listofversion/verification.json')->object();
        if($pteroaddon->verified === false) {
            throw new DisplayException('Pirated (This addon was pirated or not updated contact me on discord Bagou450#0666 or Yotapaki#8953 for talk about that)');
        }   
   	    $versions = Http::accept('application/json')->get('https://serverjars.com/api/fetchAll/mohist')->object();
	    return json_encode($versions);
    }
    public function bungeecord(Request $request)
    {    	
        $pteroaddon = Http::accept('application/json')->get('https://gameversion.bagou450.com/minecraft/listofversion/verification.json')->object();
        if($pteroaddon->verified === false) {
            throw new DisplayException('Pirated (This addon was pirated or not updated contact me on discord Bagou450#0666 or Yotapaki#8953 for talk about that)');
        }    
   	    $versions = Http::accept('application/json')->get('https://serverjars.com/api/fetchAll/bungeecord')->object();
	    return json_encode($versions);
    }
    public function velocity(Request $request)
    {    	
        $pteroaddon = Http::accept('application/json')->get('https://gameversion.bagou450.com/minecraft/listofversion/verification.json')->object();
        if($pteroaddon->verified === false) {
            throw new DisplayException('Pirated (This addon was pirated or not updated contact me on discord Bagou450#0666 or Yotapaki#8953 for talk about that)');
        }    
   	    $versions = Http::accept('application/json')->get('https://serverjars.com/api/fetchAll/velocity')->object();
	    return json_encode($versions);
    }
    public function sponge(Request $request)
    {    
        $pteroaddon = Http::accept('application/json')->get('https://gameversion.bagou450.com/minecraft/listofversion/verification.json')->object();
        if($pteroaddon->verified === false) {
            throw new DisplayException('Pirated (This addon was pirated or not updated contact me on discord Bagou450#0666 or Yotapaki#8953 for talk about that)');
        }	    
   	    $versions = Http::accept('application/json')->get('https://gameversion.bagou450.com/minecraft/listofversion/Sponge.json')->object();
	    return $versions;
    }
    public function custom(Request $request)
    {    	
        $pteroaddon = Http::accept('application/json')->get('https://gameversion.bagou450.com/minecraft/listofversion/verification.json')->object();
        if($pteroaddon->verified === false) {
            throw new DisplayException('Pirated (This addon was pirated or not updated contact me on discord Bagou450#0666 or Yotapaki#8953 for talk about that)');
        }    
        $url = $_SERVER['SERVER_NAME'];
   	    $versions = Http::accept('application/json')->get("$url/versionlist.json")->object(); 
	    return $versions;
    }
}
