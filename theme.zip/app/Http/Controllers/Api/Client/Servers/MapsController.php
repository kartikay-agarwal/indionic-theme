<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Servers;

use Pterodactyl\Exceptions\Http\Connection\DaemonConnectionException;
use Pterodactyl\Models\Server;
use Illuminate\Support\Facades\DB;
use Pterodactyl\Exceptions\DisplayException;
use Pterodactyl\Repositories\Wings\DaemonMapsRepository;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Pterodactyl\Http\Requests\Api\Client\Servers\MapManagerRequest;

class MapsController extends ClientApiController
{
    /**
     * @var \Pterodactyl\Http\Requests\Api\Client\Servers\MapManagerRequest
     */
    protected $daemonMapsRepository;

    /**
     * MapsController constructor.
     * @param DaemonMapsRepository $daemonMapsRepository
     */
    public function __construct(DaemonMapsRepository $daemonMapsRepository)
    {
        parent::__construct();

        $this->daemonMapsRepository = $daemonMapsRepository;
    }

    /**
     * @param MapManagerRequest $request
     * @param Server $server
     * @return array
     */
    public function index(MapManagerRequest $request, Server $server): array
    {
        $maps = DB::table('maps')->get();
        $installedMaps = DB::table('installed_maps')->where('server_id', '=', $server->id)->get();

        $categories = [];
        $mapsToView = [];

        foreach ($maps as $map) {
            $egg_ids = explode(',', $map->egg_id);

            if (in_array($server->egg_id, $egg_ids)) {

                checkInstalled:
                $map->installed = false;

                foreach ($installedMaps as $installedMap) {
                    if ($map->id == $installedMap->map_id) {
                        $map->installed = true;
                    }
                }
            }
        }

        return [
            'success' => true,
            'data' => [
                'maps' => $maps,
            ],
        ];
    }

    /**
     * @param MapManagerRequest $request
     * @param Server $server
     * @return array
     * @throws DisplayException
     */
    public function install(MapManagerRequest $request, Server $server): array
    {
        $mapId = trim(strip_tags($request->input('mapId', 0)));

        $map = DB::table('maps')->where('id', '=', $mapId)->get();
        if (count($map) < 1) {
            throw new DisplayException('Map not found.');
        }

        $egg_ids = explode(',', $map[0]->egg_id);
        if (!in_array($server->egg_id, $egg_ids)) {
            throw new DisplayException('Map not found.');
        }

        $mapInstalled = DB::table('installed_maps')->where('server_id', '=', $server->id)->where('map_id', '=', $mapId)->get();
        if (count($mapInstalled) > 0) {
            throw new DisplayException('This map is already installed.');
        }

        try {
            $install = $this->daemonMapsRepository->setServer($server)->install($map[0]->download_url_zip, $map[0]->decompress_type, $map[0]->install_folder);
        } catch (DaemonConnectionException $e) {
            throw new DisplayException('Failed to install the map.');
        }

        if (json_decode($install->getBody())->success != true) {
            throw new DisplayException('Failed to install the map.');
        }

        DB::table('installed_maps')->insert([
            'server_id' => $server->id,
            'map_id' => $map[0]->id,
        ]);

        return [
            'success' => true,
            'data' => [],
        ];
    }

    /**
     * @param MapManagerRequest $request
     * @param Server $server
     * @return array
     * @throws DisplayException
     */
    public function uninstall(MapManagerRequest $request, Server $server): array
    {
        $mapId = trim(strip_tags($request->input('mapId', 0)));

        $isInstalled = DB::table('installed_maps')->where('server_id', '=', $server->id)->where('map_id', '=', $mapId)->get();
        if (count($isInstalled) < 1) {
            throw new DisplayException('This map isn\'t installed.');
        }

        $map = DB::table('maps')->where('id', '=', $isInstalled[0]->map_id)->get();
        if (count($map) < 1) {
            throw new DisplayException('Map not found.');
        }

        try {
            $uninstall = $this->daemonMapsRepository->setServer($server)->uninstall($map[0]->uninstall_base == 1, $map[0]->install_folder, unserialize($map[0]->uninstall_name));
        } catch (DaemonConnectionException $e) {
            throw new DisplayException('Failed to uninstall the map.');
        }

        if (json_decode($uninstall->getBody())->success != true) {
            throw new DisplayException('Failed to uninstall the map.');
        }

        DB::table('installed_maps')->where('server_id', '=', $server->id)->where('map_id', '=', $map[0]->id)->delete();

        return [
            'success' => true,
            'data' => [],
        ];
    }
}
