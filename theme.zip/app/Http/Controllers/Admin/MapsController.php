<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Exceptions\DisplayException;
use Pterodactyl\Http\Controllers\Controller;

class MapsController extends Controller
{
    /**
     * @var \Prologue\Alerts\AlertsMessageBag
     */
    protected $alert;

    /**
     * @var array
     */
    private $decompress_methods = ['none', 'unzip'];

    /**
     * MapsController constructor.
     * @param AlertsMessageBag $alert
     */
    public function __construct(AlertsMessageBag $alert)
    {
        $this->alert = $alert;
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index()
    {
        $maps = DB::table('maps')->get();

        return view('admin.maps.index', [
            'maps' => $maps
        ]);
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function new()
    {
        $eggs = DB::table('eggs')->get();

        return view('admin.maps.new', ['eggs' => $eggs]);
    }

    /**
     * @param Request $request
     * @return RedirectResponse
     * @throws DisplayException
     * @throws \Illuminate\Validation\ValidationException
     */
    public function create(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|min:1|max:80',
            'version' => 'required',
            'images' => 'sometimes|max:190',
            'video' => 'sometimes|max:190',
            'description' => 'required|min:1|max:200',
            'egg_ids' => 'required',
            'download' => 'required|min:1|max:190',
            'decompress_type' => 'required',
            'install' => 'sometimes|max:190',
            'remove_selectors' => 'required',
        ]);

        $name = trim(strip_tags($request->input('name')));
        $version = trim(strip_tags($request->input('version')));
        $description = trim($request->input('description'));
        $images = trim($request->input('images'));
        //$images = explode(",",$images);
        //$imageNum = count($images);
        $video = trim($request->input('video'));
        $egg_ids = $request->input('egg_ids');
        $download = trim($request->input('download'));
        $decompress_type = trim($request->input('decompress_type'));
        $install = trim($request->input('install'));
        $remove_selectors = trim($request->input('remove_selectors'));
        !empty($request->input('uninstall_base', '')) ? $uninstall_base = 1 : $uninstall_base = 0;

        $remove = [];

        foreach (explode(',', $remove_selectors) as $item) {
            if (!empty($request->input('remove' . $item, ''))) {
                array_push($remove, $request->input('remove' . $item));
            }
        }

        if (!in_array($decompress_type, $this->decompress_methods)) {
            throw new DisplayException('Invalid decompress type.');
        }

        DB::table('maps')->insert([
            'name' => $name,
            'description' => $description,
            'images' => $images,
            'video' => $video,
            'version' => $version,
            'egg_id' => implode(',', $egg_ids),
            'download_url_zip' => $download,
            'decompress_type' => $decompress_type,
            'install_folder' => $install,
            'uninstall_name' => serialize($remove),
            'uninstall_base' => $uninstall_base,
        ]);

        $this->alert->success('You have successfully created new map.')->flash();

        return redirect()->route('admin.maps');
    }

    /**
     * @param $map_id
     * @return \Illuminate\Contracts\View\Factory|RedirectResponse|\Illuminate\View\View
     * @throws DisplayException
     */
    public function edit($map_id)
    {
        $map_id = (int) $map_id;

        $map = DB::table('maps')->where('id', '=', $map_id)->get();
        if (count($map) < 1) {
            throw new DisplayException('Map not found.');
        }

        $eggs = DB::table('eggs')->get();

        $key = 0;
        $removes = '';

        foreach (unserialize($map[0]->uninstall_name) as $item) {
            $key = $key + 1;
            empty($removes) ? $removes = $key : $removes = $removes . ',' . $key;
        }

        return view('admin.maps.edit', ['map' => $map[0], 'eggs' => $eggs, 'removes' => $removes]);
    }

    /**
     * @param Request $request
     * @param $map_id
     * @return RedirectResponse
     * @throws DisplayException
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request, $map_id)
    {
        $map_id = (int) $map_id;

        $domain = DB::table('maps')->where('id', '=', $map_id)->get();
        if (count($domain) < 1) {
            throw new DisplayException('Map not found.');
        }

        $this->validate($request, [
            'name' => 'required|min:1|max:80',
            'version' => 'required',
            'images' => 'sometimes|max:500',
            'video' => 'sometimes|max:190',
            'description' => 'required|min:1|max:200',
            'egg_ids' => 'required',
            'download' => 'required|min:1|max:190',
            'decompress_type' => 'required',
            'install' => 'sometimes|max:190',
            'remove_selectors' => 'sometimes',
        ]);

        $name = trim(strip_tags($request->input('name')));
        $version = trim(strip_tags($request->input('version')));
        $description = trim($request->input('description'));
        $images = trim($request->input('images'));
        //$images = explode(",",$images);
        //$imageNum = count($images);
        $video = trim($request->input('video'));
        $egg_ids = $request->input('egg_ids');
        $download = trim($request->input('download'));
        $decompress_type = trim($request->input('decompress_type'));
        $install = trim($request->input('install'));
        $remove_selectors = trim($request->input('remove_selectors'));
        !empty($request->input('uninstall_base', '')) ? $uninstall_base = 1 : $uninstall_base = 0;

        $remove = [];

        foreach (explode(',', $remove_selectors) as $item) {
            if (!empty($request->input('remove' . $item, ''))) {
                array_push($remove, $request->input('remove' . $item));
            }
        }

        if (!in_array($decompress_type, $this->decompress_methods)) {
            throw new DisplayException('Invalid decompress type.');
        }

        DB::table('maps')->where('id', '=', $map_id)->update([
            'name' => $name,
            'description' => $description,
            'images' => $images,
            'video' => $video,
            'version' => $version,
            'egg_id' => implode(',', $egg_ids),
            'download_url_zip' => $download,
            'decompress_type' => $decompress_type,
            'install_folder' => $install,
            'uninstall_name' => serialize($remove),
            'uninstall_base' => $uninstall_base,
        ]);

        $this->alert->success('You have successfully edited this map.')->flash();

        return redirect()->route('admin.maps.edit', $map_id);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function delete(Request $request)
    {
        $map_id = (int) $request->input('id', '');

        $map = DB::table('maps')->where('id', '=', $mapd_id)->get();
        if (count($map) < 1) {
            return response()->json(['error' => 'Map not found.'])->setStatusCode(500);
        }

        DB::table('maps')->where('id', '=', $map_id)->delete();

        return response()->json(['success' => true]);
    }
}
