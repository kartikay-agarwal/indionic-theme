<?php

namespace Pterodactyl\Http\Requests\Api\Client;

use Pterodactyl\Http\Requests\Api\Client\ClientApiRequest;

class AnnouncementRequest extends ClientApiRequest
{
    /**
     * @return string
     */
}
