<?php

namespace Pterodactyl\Classes\Exceptions;

class MinecraftQueryException extends \Exception
{
    // Exception thrown by MinecraftPing class
}
