<?php

namespace Pterodactyl\Exceptions\Service\Egg;

use Pterodactyl\Exceptions\DisplayException;

class BadJsonFormatException extends DisplayException
{
}
